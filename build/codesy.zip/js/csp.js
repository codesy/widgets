var addCodesy, cspAppender, githubFilter;

githubFilter = {
  urls: ["https://github.com/*"],
  types: ["main_frame"]
};

cspAppender = function(domain) {
  var types;
  this.domain = domain;
  types = ['connect-src', 'frame-src', 'script-src', 'style-src'];
  this.isCSP = function(headerName) {
    return (headerName === 'CONTENT-SECURITY-POLICY') || (headerName === 'X-WEBKIT-CSP');
  };
  return (function(_this) {
    return function(details) {
      var header, i, j, len, len1, ref, type;
      ref = details.responseHeaders;
      for (i = 0, len = ref.length; i < len; i++) {
        header = ref[i];
        if (_this.isCSP(header.name.toUpperCase())) {
          for (j = 0, len1 = types.length; j < len1; j++) {
            type = types[j];
            header.value = header.value.replace(type, type + " " + _this.domain);
          }
        }
      }
      return {
        responseHeaders: details.responseHeaders
      };
    };
  })(this);
};

addCodesy = new cspAppender("");

chrome.storage.local.get(null, function(data) {
  addCodesy = new cspAppender(data.domains[0].domain);
  return chrome.webRequest.onHeadersReceived.addListener(addCodesy, githubFilter, ["responseHeaders", "blocking"]);
});

chrome.storage.onChanged.addListener(function(changes, namespace) {
  void 0;
  if (changes.domains.newValue[0].domain) {
    if (chrome.webRequest.onHeadersReceived.hasListener(addCodesy)) {
      chrome.webRequest.onHeadersReceived.removeListener(addCodesy);
    }
    addCodesy = new cspAppender(changes.domains.newValue[0].domain);
    return chrome.webRequest.onHeadersReceived.addListener(addCodesy, githubFilter, ["responseHeaders", "blocking"]);
  }
});
