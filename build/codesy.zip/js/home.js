var codesy, codesy_home, isChrome, ref;

void 0;

void 0;

if ($(".installed").length > 0) {
  $(".install-step").hide();
  $(".installed").show();
}

codesy = {};

isChrome = (ref = chrome.storage) != null ? ref : false;

if (isChrome) {
  codesy.find = function(domains, domain) {
    return domains.map(function(item) {
      return item.domain;
    }).indexOf(domain);
  };
  codesy.save = function(home) {
    return chrome.storage.local.get(null, function(data) {
      var idx;
      void 0;
      data.domains = data.domains || [];
      idx = codesy.find(data.domains, home.domain);
      if (idx !== -1) {
        data.domains.splice(idx, 1);
      }
      data.domains.unshift(home);
      return chrome.storage.local.set(data);
    });
  };
} else {
  codesy.save = function(home) {
    void 0;
    return chrome.runtime.sendMessage(home);
  };
}

codesy_home = {
  'task': "setHome",
  'domain': window.location.origin
};

codesy.save(codesy_home);

void 0;
